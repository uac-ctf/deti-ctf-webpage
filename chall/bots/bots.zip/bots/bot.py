import requests
import time

url="place the URL here"
privateToken="place your token here"
urlGET = url + "/?token=" + privateToken
urlPOST = url + "/api/post/"

while True:
	try:
		client = requests.Session()
		r = client.get(urlGET)

		for x in r.text.split("\n"):
			if "csrf-token" in x:
				tmp = x
				break
		cookie=x.split("\"")[3]


		headers = {
		    'accept': 'text/html,application/xhtml+xml,application/xml',
		    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
		    'X-CSRF-Token':cookie
		}


		r = client.get(urlPOST)
		query={"wish_id":1473222501,"value":1,"reaction_type":"like"}
		r = client.post(urlPOST, data=query, headers = headers)
		print (r.text)

		time.sleep(5)
		
		query={"wish_id":1470480643,"value":1,"reaction_type":"like"}
		r = client.post(urlPOST, data=query, headers = headers)
		print (r.text)

		time.sleep(7)
	except:
		pass